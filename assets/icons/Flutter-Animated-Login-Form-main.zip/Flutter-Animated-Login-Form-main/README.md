# rive_teddy_bear

A project to demostrate about the rive annimations in Flutter.

